<?php defined('SYSPATH') or die('No direct script access.');

return array(
	'purifier' => array(
		'name'  => 'Purifier',
		'title' => 'HTML Purifier for Kohana',
		'url'   => 'https://github.com/shadowhand/purifier',
	),
);
